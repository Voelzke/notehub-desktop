---
title: Auftrag 2026-02-18 SSL-Zertifikate erneuern
tags: [auftrag, sicherheit, server]
type: task
due: 2026-02-25
priority: medium
status: open
---

# SSL-Zertifikate erneuern

**Erstellt:** 2026-02-18 14:00

---

## Betroffene Domains

- [ ] werkannwas.org – läuft ab 27.02.
- [ ] anglerclub-nassau.de – läuft ab 01.03.
- [ ] praxis-dr-klein.de – läuft ab 03.03.
- [x] voelzke.de – bereits erneuert ✅
- [x] nextcloud.voelzke.de – bereits erneuert ✅

## Vorgehen

Let's Encrypt Certbot automatisch erneuern:

```bash
sudo certbot renew --dry-run
sudo certbot renew
```

## Hinweis

Certbot Auto-Renewal Cronjob prüfen! Bei werkannwas.org ist der Cron seit dem Server-Umzug nicht aktiv.
