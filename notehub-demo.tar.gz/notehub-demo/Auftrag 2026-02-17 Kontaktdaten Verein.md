---
title: Auftrag 2026-02-17 Kontaktdaten-Import Verein
tags: [auftrag, nextcloud, kunde]
type: task
due: 2026-02-28
priority: medium
status: open
contacts:
  - name: Klaus Becker
    company: Anglerclub Nassau e.V.
---

# Kontaktdaten-Import Anglerclub Nassau

**Erstellt:** 2026-02-17 16:00

---

## Aufgabe

Die Mitglieder-Datenbank des Anglerclubs (Excel-Datei mit 340 Mitgliedern) soll in die Nextcloud-Kontakte importiert werden.

## Schritte

- [x] Excel-Datei erhalten und geprüft
- [x] Datenqualität: 12 doppelte Einträge gefunden
- [ ] Duplikate mit Herrn Becker klären
- [ ] CSV-Export für CardDAV-Import vorbereiten
- [ ] Testlauf mit 10 Kontakten
- [ ] Vollständiger Import
- [ ] Herrn Becker einweisen

## Hinweise

- Einige Mitglieder haben keine E-Mail-Adresse
- Vereinsbeiträge sollen als Notiz im Kontakt stehen
- Geburtstage importieren für den Kalender
