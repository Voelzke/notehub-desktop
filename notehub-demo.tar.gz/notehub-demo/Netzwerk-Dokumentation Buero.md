---
title: Netzwerk-Dokumentation Büro Nastätten
tags: [dokumentation, netzwerk, intern]
type: note
---

# Netzwerk-Dokumentation Büro

**Letzte Aktualisierung:** 2026-02-18

---

## Übersicht

| Gerät | IP-Adresse | Funktion |
|-------|-----------|----------|
| Firewall | 192.168.1.1 | pfSense, VPN Gateway |
| Proxmox Host | 192.168.1.10 | Virtualisierung |
| NAS Synology | 192.168.1.20 | Backup, Fileserver |
| Switch PoE | 192.168.1.2 | 24-Port managed |
| AP Büro | 192.168.1.30 | UniFi AP Pro |
| Drucker | 192.168.1.50 | HP LaserJet |

## VLANs

- **VLAN 10** – Server (192.168.10.0/24)
- **VLAN 20** – Arbeitsplätze (192.168.20.0/24)
- **VLAN 30** – Gäste-WLAN (192.168.30.0/24)
- **VLAN 40** – IoT / Telefonie (192.168.40.0/24)

## VPN

- WireGuard auf pfSense
- Port: 51820/UDP
- Peers: 5 aktive Verbindungen (Ralf, Christian, 3 Kunden)

## Wichtige Zugangsdaten

Passwörter im KeePass-Tresor: `\\NAS\IT\Passwoerter.kdbx`
