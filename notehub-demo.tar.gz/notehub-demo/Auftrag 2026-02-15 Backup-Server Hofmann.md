---
title: Auftrag 2026-02-15 Backup-Server einrichten
tags: [auftrag, server, erledigt]
type: task
due: 2026-02-18
priority: medium
status: completed
contacts:
  - name: Bernd Hofmann
    company: Weingut Hofmann
---

# Backup-Server Weingut Hofmann

**Erstellt:** 2026-02-15 08:00
**Erledigt:** 2026-02-17 16:30 ✅

---

## Durchgeführte Arbeiten

- [x] Backup-Server (Proxmox VM) eingerichtet
- [x] Tägliche Snapshots konfiguriert (03:00 Uhr)
- [x] Wöchentliches Offsite-Backup auf NAS
- [x] Monitoring eingerichtet (E-Mail bei Fehler)
- [x] Restore-Test durchgeführt
- [x] Dokumentation an Herrn Hofmann übergeben

## Konfiguration

- VM: 4 vCPU, 8 GB RAM, 500 GB Storage
- Backup-Tool: Borgmatic
- Retention: 7 tägliche, 4 wöchentliche, 3 monatliche
- Offsite: Synology NAS im Keller (verschlüsselt)

## Rechnung

3,5 Stunden × 85 €/h = 297,50 € zzgl. MwSt.
Rechnung Nr. 2026-0047 erstellt.
