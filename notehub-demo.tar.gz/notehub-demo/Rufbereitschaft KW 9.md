---
title: Rufbereitschaft KW 9
tags: [intern, rufbereitschaft]
type: note
---

# Rufbereitschaft KW 9 (24.02. – 28.02.)

**Christian Friedlein** ist diese Woche in Rufbereitschaft.

## Erreichbarkeit

- Handy: 0151-12345678
- Ticket-System: support@voelzke.de
- Reaktionszeit: max. 2 Stunden

## Wichtige Kunden diese Woche

- **Bäckerei Schmitt** – Webshop wird aktualisiert (Di/Mi)
- **Dr. Klein** – IPv6-Umstellung (Mi Abend)
- **Weingut Hofmann** – Backup-Monitoring läuft, keine Aktion nötig

## Eskalation

Bei Serverausfall oder Sicherheitsvorfall: Ralf direkt anrufen.
