---
title: Gasabrechnung 2025 prüfen
tags: [privat, finanzen]
type: task
due: 2026-02-20
priority: low
status: completed
---

# Gasabrechnung 2025 prüfen

**Erstellt:** 2026-01-12 14:09
**Erledigt:** 2026-02-19 ✅

---

## Ergebnis

- Jahresverbrauch: 12.450 kWh (Vorjahr: 14.200 kWh → **-12%!**)
- Kosten: 1.245 € (Vorjahr: 1.562 €)
- Guthaben: 187,30 € → wird erstattet

## Notizen

Die neue Heizungssteuerung hat sich gelohnt. Nachtabsenkung auf 16°C spart deutlich.

Beleg abgeheftet in: Ordner "Finanzen/2025/Nebenkosten"
