---
title: Einkaufsliste Bürobedarf 2026-02-22
tags: [einkauf, büro]
type: note
---

# Einkaufsliste Bürobedarf

**Erstellt:** 2026-02-22 08:30

---

- [ ] Druckerpapier A4 (2 Pakete)
- [ ] Toner HP LaserJet (schwarz + cyan)
- [ ] USB-C Kabel 2m (3 Stück)
- [ ] Kabelbinder sortiert
- [x] Bildschirmreiniger
- [x] Mousepad ergonomisch
- [ ] Cat6a Patchkabel 3m (10 Stück)
- [ ] Schrumpfschlauch-Set
- [ ] Kaffee (Lavazza, ganze Bohnen)
- [ ] Milch für die Küche
