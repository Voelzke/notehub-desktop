---
title: Auftrag 2026-02-17 Shopupdate Bäckerei Schmitt
tags: [auftrag, webshop, dringend]
type: task
due: 2026-02-21
priority: high
status: open
contacts:
  - name: Thomas Schmitt
    company: Bäckerei Schmitt
---

# Shopupdate Bäckerei Schmitt

**Erstellt:** 2026-02-17 14:30
**Fällig:** 2026-02-21 ⚠️

---

## Problem

Der Webshop zeigt seit dem PHP-Update falsche Preise an. Einige Produkte haben 0,00 € als Preis. Kunde ist verärgert, da Bestellungen reinkommen mit falschen Preisen.

## Analyse

- PHP 8.4 hat `number_format()` Verhalten geändert
- WooCommerce-Plugin nicht kompatibel mit PHP 8.4
- Betroffene Produkte: ca. 45 von 120

## To-Do

- [x] Problem reproduziert
- [x] Ursache gefunden (PHP 8.4 Kompatibilität)
- [ ] WooCommerce-Plugin aktualisieren
- [ ] Preise manuell prüfen
- [ ] Testbestellung durchführen
- [ ] Herrn Schmitt informieren

## Kontakt

Thomas Schmitt hat morgen ab 8 Uhr Zeit für einen Testlauf. Rufnummer: 06772-12345
