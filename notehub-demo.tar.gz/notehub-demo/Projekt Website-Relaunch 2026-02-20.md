---
title: Projekt Website-Relaunch 2026-02-20
tags: [projekt, webdesign, kunde]
type: task
due: 2026-03-15
priority: high
status: open
contacts:
  - name: Sandra Müller
    company: Autohaus Rheintal GmbH
  - name: Marco Weber
    company: Webdesign Weber
---

# Website-Relaunch Autohaus Rheintal

**Erstellt:** 2026-02-20 09:15
**Projekt:** Website-Relaunch

---

## Ziel

Kompletter Relaunch der Firmenwebsite mit neuem Design, mobilfreundlich und SEO-optimiert. Der Kunde wünscht eine moderne Darstellung mit Fahrzeug-Galerie und Online-Terminbuchung.

## Status

- [x] Erstgespräch mit Sandra Müller geführt
- [x] Angebot erstellt und freigegeben
- [x] Design-Entwurf von Marco Weber erhalten
- [ ] Responsive Umsetzung
- [ ] Testphase
- [ ] Go-Live

## Nächste Schritte

1. Design-Feedback bis 25.02. einarbeiten
2. Fahrzeug-Galerie implementieren
3. Kontaktformular mit E-Mail-Weiterleitung

## Budget

- Design: 1.200 €
- Umsetzung: 2.800 €
- Hosting (1 Jahr): 180 €

## Notizen

Sandra möchte unbedingt eine WhatsApp-Integration. Marco prüft Datenschutz-Konformität.

Siehe auch: [[Auftrag Website-Hosting Rheintal]]
