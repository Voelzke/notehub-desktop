---
title: Auftrag Website-Hosting Rheintal
tags: [auftrag, hosting, kunde]
type: task
due: 2026-04-01
priority: low
status: open
contacts:
  - name: Sandra Müller
    company: Autohaus Rheintal GmbH
---

# Website-Hosting Autohaus Rheintal

**Erstellt:** 2026-02-20 10:00

---

## Beschreibung

Nach dem Website-Relaunch soll das Hosting von Strato zu unserem eigenen Server migriert werden. Vertrag bei Strato läuft zum 01.04. aus.

## To-Do

- [ ] DNS-Einträge vorbereiten
- [ ] SSL-Zertifikat (Let's Encrypt) einrichten
- [ ] Apache vHost konfigurieren
- [ ] E-Mail-Weiterleitung einrichten
- [ ] Migration testen
- [ ] DNS umstellen
- [ ] Strato-Vertrag kündigen

## Hosting-Details

- Domain: autohaus-rheintal.de
- Server: vm11 (Proxmox)
- PHP 8.3, MariaDB 10.11
- Backup: täglich, 30 Tage Retention

Siehe auch: [[Projekt Website-Relaunch 2026-02-20]]
