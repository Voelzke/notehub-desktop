---
title: Idee Managed Nextcloud Service
tags: [idee, geschäft, nextcloud]
type: note
---

# Idee: Managed Nextcloud as a Service

**Erstellt:** 2026-02-10

---

## Konzept

Managed Nextcloud für kleine Unternehmen und Vereine anbieten. Viele kennen Nextcloud nicht, wollen aber eine Dropbox-Alternative mit Datenschutz.

## Zielgruppe

- Handwerksbetriebe (5-20 Mitarbeiter)
- Arztpraxen (DSGVO!)
- Vereine
- Freiberufler

## Preismodell

| Paket | Speicher | User | Preis/Monat |
|-------|----------|------|-------------|
| Starter | 50 GB | 5 | 9,90 € |
| Business | 200 GB | 15 | 24,90 € |
| Professional | 1 TB | 50 | 49,90 € |

## Enthaltene Apps

- Files, Kalender, Kontakte
- **NoteHub** (!) – Notizen & Aufgaben
- Talk (Video-Konferenzen)
- Office (Collabora)

## Nächste Schritte

- [ ] Kalkulation: Server-Kosten pro Kunde
- [ ] Landing Page erstellen
- [ ] 3 Pilotkunden finden
- [ ] Automatisierte Einrichtung (Ansible)

## Wettbewerb

Hetzner StorageShare: 4,58 €/Monat für 1 TB, aber ohne Support und ohne managed.
Unser Vorteil: Persönlicher Service, regionale Nähe, Einrichtung inklusive.
