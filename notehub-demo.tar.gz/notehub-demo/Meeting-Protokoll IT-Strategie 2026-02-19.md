---
title: Meeting-Protokoll IT-Strategie 2026-02-19
tags: [meeting, strategie, intern]
type: note
contacts:
  - name: Christian Friedlein
    company: IT-Dienstleistungen Völzke
---

# Meeting-Protokoll: IT-Strategie Q1 2026

**Datum:** 2026-02-19 10:00 – 11:30
**Teilnehmer:** Ralf Völzke, Christian Friedlein
**Ort:** Büro Nastätten

---

## Agenda

1. Rückblick Q4 2025
2. Neue Kunden-Akquise
3. Server-Infrastruktur
4. Schulung Christian

## Besprochenes

### Rückblick Q4 2025
- 3 neue Kunden gewonnen
- Umsatz 12% über Plan
- Hosting-Migration für 2 Kunden abgeschlossen

### Neue Kunden-Akquise
- Angebot für Weingut Lorenz steht aus → Christian folgt nach
- Anfrage Anglerclub Nassau für Website-Pflege
- Mögliche Kooperation mit Webdesign Weber für größere Projekte

### Server-Infrastruktur
- Proxmox-Cluster läuft stabil
- ZFS ARC Memory auf 4GB begrenzt → Performance OK
- Backup-Strategie: Tägliche Snapshots + wöchentlich offsite

### Schulung Christian
- Nextcloud-Administration: 80% abgeschlossen
- Nächste Woche: Firewall-Konfiguration
- Danach: Kundensupport-Prozesse

## Aufgaben

| Aufgabe | Verantwortlich | Fällig |
|---------|---------------|--------|
| Angebot Weingut nachfassen | Christian | 26.02. |
| Backup offsite einrichten | Ralf | 01.03. |
| Support-Prozess dokumentieren | Christian | 05.03. |
