---
title: Auftrag 2026-02-20 ipv6 für Praxis Dr. Klein
tags: [auftrag, netzwerk, kunde]
type: task
due: 2026-03-01
priority: medium
status: open
contacts:
  - name: Dr. Markus Klein
    company: Zahnarztpraxis Dr. Klein
---

# IPv6-Einrichtung Praxis Dr. Klein

**Erstellt:** 2026-02-20 11:00

---

## Auftragsbeschreibung

Umstellung des Praxis-Netzwerks auf Dual-Stack (IPv4 + IPv6). Der Provider hat IPv6 freigeschaltet, die Firewall muss konfiguriert werden.

## Schritte

- [x] IPv6-Präfix vom Provider erhalten (2a02:8109:9e40::/48)
- [x] Firewall-Regeln geplant
- [ ] Router-Konfiguration anpassen
- [ ] Firewall IPv6-Regeln aktivieren
- [ ] Praxis-PCs testen
- [ ] VPN-Zugang prüfen
- [ ] Medizinische Geräte isolieren (VLAN)

## Hinweise

- Medizinische Geräte dürfen **nicht** über IPv6 erreichbar sein!
- VPN muss weiterhin über IPv4 laufen (Telematik-Infrastruktur)
- Termin vor Ort: Mittwoch 26.02., 18:00 (nach Praxisschluss)
