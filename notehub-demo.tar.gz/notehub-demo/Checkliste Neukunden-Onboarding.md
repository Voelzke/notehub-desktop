---
title: Checkliste Neukunden-Onboarding
tags: [vorlage, intern, prozess]
type: note
shared_with:
  - user: Friedlein
    permission: read
---

# Checkliste: Neukunden-Onboarding

**Version:** 1.2 | **Letzte Änderung:** 2026-02-15

---

## Vor dem Ersttermin

- [ ] Kontaktdaten im Adressbuch anlegen
- [ ] Firma und Branche recherchieren
- [ ] Bestehende IT-Infrastruktur erfragen

## Ersttermin

- [ ] Anforderungen aufnehmen
- [ ] Bestandsaufnahme IT (Server, Netzwerk, Software)
- [ ] Budget-Rahmen klären
- [ ] Ansprechpartner und Erreichbarkeit notieren

## Nach dem Ersttermin

- [ ] Angebot erstellen (Vorlage: `Vorlagen/Angebot-IT.docx`)
- [ ] Angebot per E-Mail senden
- [ ] Nachfassen nach 5 Werktagen
- [ ] Bei Zusage: Auftrag in NoteHub anlegen

## Einrichtung

- [ ] Nextcloud-Account anlegen (wenn gewünscht)
- [ ] VPN-Zugang einrichten
- [ ] Monitoring aktivieren
- [ ] Dokumentation anlegen → [[Netzwerk-Dokumentation Büro Nastätten]]

## Abschluss

- [ ] Übergabe-Gespräch mit Kunden
- [ ] Wartungsvertrag anbieten
- [ ] Erste Rechnung stellen
